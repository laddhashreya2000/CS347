#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int main(void)
{
  printf(1, "Hello, world!\n");
  int v=numvp();
  printf(1, "VP: %d\n", v);
  int p = numpp();
  printf(1, "PP: %d\n", p);
  exit();
}
