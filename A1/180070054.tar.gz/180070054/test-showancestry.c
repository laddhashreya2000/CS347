#include "types.h"
#include "stat.h"
#include "user.h"

int main(void)
{
    for (int i = 0; i < 4; i++){
        int pid;
	pid = fork();
	
	if(pid!=0)
	{
		wait();
		printf(1,"Process ID %d\n", getpid());
		showAncestry();
	}
	else
	{
		printf(1,"Process ID %d\n", getpid());
		showAncestry();
	}
    }
    exit();
}