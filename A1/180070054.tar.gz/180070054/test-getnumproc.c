#include "types.h"
#include "stat.h"
#include "user.h"

int main(void)
{
    for (int i = 0; i < 2; i++){
        int pid;
	pid = fork();
	printf(1, "Number of processes: %d\n", getNumProc());
	if(pid!=0)
		wait();
    }
    exit();
}