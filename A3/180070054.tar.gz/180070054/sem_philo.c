#include <stdio.h>
#include <pthread.h>
#include "zemaphore.h"
#include <time.h>

#define NUM 5
enum { THINK, HUNGRY, EAT } state[NUM]; //three states

zem_t mutex;
zem_t S[NUM];

void waitFor (unsigned int t) { //standard sleep time function
  unsigned int ret;
  ret = time(0) + t;
  while (time(0) < ret); 
}

void check_update(int id)
{
    //three condition - self, left, right person
  if (state[id] == HUNGRY &&  state[(id+NUM-1)%NUM] != EAT && state[(id+1)%NUM] != EAT) {
    state[id] = EAT;  
    printf("%d Philosopher eat.\n", id + 1);
    waitFor(2); //wait 2 second to finish eating
    zem_up(&S[id]); //this means it has eaten so increment
  }
  return;
}
 

void pick(int id)
{
 
    zem_down(&mutex); //used for locking
 
   //printf("%d Philosopher tries to pick.\n", id + 1);
   state[id] = HUNGRY; //update state before actual picking
 
    //check if left or right person eating. Can't pick then.
    check_update(id); 
 
    zem_up(&mutex);
    zem_down(&S[id]); //if not eat, then wait else continue //blocks if this line before mutex one.
    return;
}
 

void put(int id)
{
 
    zem_down(&mutex);
 
    state[id] = THINK;
  printf("%d Philosopher stop eating. Start thinking.\n", id + 1);
 
    check_update((id+1)%NUM); //Right person
    check_update((id+NUM-1)%NUM); //left person
 
    zem_up(&mutex);
    return;
}
 
void* start_process(void* arg)
{
   while(1) { //runs forever
    int *id = (int *)arg;
    printf("%d Philosopher thinks.\n", *id + 1);
    waitFor(1);  // 1 sec for thinking time
    //alternate between thinking and eating.
    pick(*id); //when wishing to eat
    put(*id); //when finishing eating
  }
   return NULL;
}

int main()
{
 
    int id_phil[NUM];
    pthread_t num_thread[NUM];
 
    // initialisation
    zem_init(&mutex, 1);
    for (int i = 0; i < NUM; i++){
 	id_phil[i] = i;
        zem_init(&S[i], 0);
    }

    /* Creating environment */
  for (int i = 0; i < NUM; i++) {
    // creating a seperate thread for each philosopher
    pthread_create(&num_thread[i], NULL, start_process, &id_phil[i]); //sitting on the table
    printf("Thread #%d created. %d Philosopher sits.\n", i + 1, i+1);
    waitFor(1); //random time wait for letting all sit.
  }
 
    for (int i = 0; i < NUM; i++){
    pthread_join(num_thread[i], NULL);
  }

  return 0;
}