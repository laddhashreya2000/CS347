#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <wait.h>
#include "zemaphore.h"

void zem_init(zem_t *s, int value) {
  s->value = value;
  s->condition = PTHREAD_COND_INITIALIZER;
  s->mutex = PTHREAD_MUTEX_INITIALIZER;
  return;
}

void zem_down(zem_t *s) {

  pthread_mutex_lock(&(s->mutex)); //locking beforehand
  s->value = s->value-1; //decrement
  if(s->value<0){ //wait using condition variable
	pthread_cond_wait(&(s->condition), &(s->mutex));
  }
  pthread_mutex_unlock(&(s->mutex));
  return;
}

void zem_up(zem_t *s) {
  pthread_mutex_lock(&(s->mutex)); //locking beforehand
  s->value= s->value+1; //increment
  pthread_cond_signal(&(s->condition));
  pthread_mutex_unlock(&(s->mutex));
  return;
}
