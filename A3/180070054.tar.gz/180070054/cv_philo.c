#include <pthread.h>
#include <stdio.h>
#include <time.h>

#define NUM 5 //number of philosopher on table
enum { THINK, HUNGRY, EAT } state[NUM]; //three states

pthread_mutex_t mutex;
pthread_cond_t cond[NUM];

void waitFor (unsigned int t) { //standard sleep time function
  unsigned int ret;
  ret = time(0) + t;
  while (time(0) < ret); 
}

void check_update(int id) {//check if possible to pick and update state function
 
   //three condition - self, left, right person
  if (state[id] == HUNGRY &&  state[(id+NUM-1)%NUM] != EAT && state[(id+1)%NUM] != EAT) {
    state[id] = EAT;  
    printf("%d Philosopher eat.\n", id + 1);

    waitFor(2); //wait 2 second to finish eating

    pthread_cond_signal(&cond[id]); //signal back to signify finish eating. It blocks the forks till it finishes eating
  }
  return;
}

void put(int id) {//finish eating and start thinking

  pthread_mutex_lock(&mutex); //locking before

  state[id] = THINK;
  printf("%d Philosopher stop eating. Start thinking.\n", id + 1);

  //now update the right and left person state accordingly.
  check_update((id+1)%NUM); //Right person
  check_update((id+NUM-1)%NUM); //left person
  
  pthread_mutex_unlock(&mutex);

  return;
}

void pick(int id) {//wait and eat

  pthread_mutex_lock(&mutex); //locking before

  printf("%d Philosopher tries to pick.\n", id + 1);
  state[id] = HUNGRY; //update state before actual picking

  //check if left or right person eating. Can't pick then.
  check_update(id); 

  while (state[id] != EAT){ //use of cond variable to wait
    pthread_cond_wait(&cond[id], &mutex); //wait till state is eat
  }

  pthread_mutex_unlock(&mutex);
  return;
}

void *start_process(void *arg) //void * bcuz of pthread_create function
{
  while(1) { //runs forever
    int *id = (int *)arg;
    printf("%d Philosopher thinks.\n", *id + 1);
    waitFor(1);  // 1 sec for thinking time
    //alternate between thinking and eating.
    pick(*id); //when wishing to eat
    put(*id); //when finishing eating
  }
  // return; - error for void *
}


int main()
{
  pthread_t num_thread[NUM];
  int id_phil[NUM];

  /* Initialisations */
  pthread_mutex_init(&mutex, NULL);
  for (int i = 0; i < NUM; i++) {
    id_phil[i] = i;
    pthread_cond_init(&cond[i], NULL);
  }

  /* Creating environment */
  for (int i = 0; i < NUM; i++) {
    // creating a seperate thread for each philosopher
    pthread_create(&num_thread[i], NULL, start_process, &id_phil[i]); //sitting on the table
    printf("Thread #%d created. %d Philosopher sits.\n", i + 1, i+1);
    waitFor(1); //random time wait for letting all sit.
  }

  for (int i = 0; i < NUM; i++){
    pthread_join(num_thread[i], NULL);
  }

  return 0;
}
