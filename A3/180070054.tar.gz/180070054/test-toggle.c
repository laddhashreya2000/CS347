#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <wait.h>
#include <pthread.h>
#include "zemaphore.h"

#define NUM_THREADS 3
#define NUM_ITER 10

zem_t iter[NUM_ITER]; 
zem_t s;

void *justprint(void *data)
{
  int thread_id = *((int *)data);

  for(int i=0; i < NUM_ITER; i++)
    {
      zem_down(&iter[i]); //lock for iteration
      printf("This is thread %d\n", thread_id);
      if(thread_id==NUM_THREADS-1 && i<NUM_ITER-1)
		zem_up(&iter[i+1]); //the next iteration no need to wait when the last one prints
	zem_up(&s); //release for thread
      zem_up(&iter[i]); //release for iteration
    }
  return 0;
}

int main(int argc, char *argv[])
{
  zem_init(&iter[0],1);//first to succeed
  zem_init(&s,1); //first should succeed
  for(int i=1; i<NUM_ITER; i++){
       zem_init(&iter[i],0);//the first call to block
  }

  pthread_t mythreads[NUM_THREADS];
  int mythread_id[NUM_THREADS];

  
  for(int i =0; i < NUM_THREADS; i++)
    {
      mythread_id[i] = i;
      zem_down(&s);
      pthread_create(&mythreads[i], NULL, justprint, (void *)&mythread_id[i]);
      
    }
  
  for(int i =0; i < NUM_THREADS; i++)
    {
      pthread_join(mythreads[i], NULL);
    }
  
  return 0;
}
